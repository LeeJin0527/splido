﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// My4122.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_MY4_12_2_FORM               101
#define IDR_MAINFRAME                   128
#define IDR_My4122TYPE                  130
#define IDC_LIST1                       1000
#define IDC_LIST2                       1001
#define IDC_LIST3                       1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        311
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
